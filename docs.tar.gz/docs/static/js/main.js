// 澳门金尊产品培训系统 - 移动端优化
document.addEventListener('DOMContentLoaded', function() {
    // 导航栏激活
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.navbar-item').forEach(item => {
        if (item.getAttribute('href') === currentPage) {
            item.classList.add('active');
        }
    });
    
    // 移动端菜单
    if (window.innerWidth < 768) {
        const menu = document.querySelector('.navbar-menu');
        if (menu) {
            menu.style.display = 'none';
            const toggleBtn = document.createElement('button');
            toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';
            toggleBtn.style.background = 'none';
            toggleBtn.style.border = 'none';
            toggleBtn.style.color = 'white';
            toggleBtn.style.fontSize = '24px';
            toggleBtn.style.cursor = 'pointer';
            toggleBtn.onclick = () => {
                menu.style.display = menu.style.display === 'flex' ? 'none' : 'flex';
            };
            document.querySelector('.navbar-container').appendChild(toggleBtn);
        }
    }
});